package com.zubdati.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Forest = Color(0xFF245B46)
private val Mint = Color(0xFFE8F2EA)
private val Ink = Color(0xFF1D2A23)
private val Muted = Color(0xFF6C7A71)

data class Meal(
    val name: String,
    val calories: Int,
    val protein: Int,
    val carbs: Int,
    val fat: Int,
    val day: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Forest,
                    onPrimary = Color.White,
                    background = Color(0xFFF7F8F4),
                    surface = Color.White
                )
            ) {
                ZubdatiApp(this)
            }
        }
    }
}

private fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

private fun loadMeals(context: Context): MutableList<Meal> {
    val raw = context.getSharedPreferences("zubdati", Context.MODE_PRIVATE)
        .getString("meals", "[]") ?: "[]"
    val result = mutableListOf<Meal>()
    try {
        val array = JSONArray(raw)
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            result.add(Meal(
                o.optString("name"), o.optInt("calories"), o.optInt("protein"),
                o.optInt("carbs"), o.optInt("fat"), o.optString("day")
            ))
        }
    } catch (_: Exception) {}
    return result
}

private fun saveMeals(context: Context, meals: List<Meal>) {
    val array = JSONArray()
    meals.forEach { m ->
        array.put(JSONObject().apply {
            put("name", m.name); put("calories", m.calories)
            put("protein", m.protein); put("carbs", m.carbs)
            put("fat", m.fat); put("day", m.day)
        })
    }
    context.getSharedPreferences("zubdati", Context.MODE_PRIVATE)
        .edit().putString("meals", array.toString()).apply()
}

@Composable
private fun ZubdatiApp(context: Context) {
    val meals = remember { mutableStateListOf<Meal>().apply { addAll(loadMeals(context)) } }
    var showAdd by remember { mutableStateOf(false) }
    var showPhotoInfo by remember { mutableStateOf(false) }
    var goal by remember {
        mutableIntStateOf(context.getSharedPreferences("zubdati", Context.MODE_PRIVATE)
            .getInt("goal", 2200))
    }
    val todays = meals.filter { it.day == todayKey() }
    val calories = todays.sumOf { it.calories }
    val protein = todays.sumOf { it.protein }
    val carbs = todays.sumOf { it.carbs }
    val fat = todays.sumOf { it.fat }

    CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { showAdd = true },
                    containerColor = Forest,
                    contentColor = Color.White
                ) { Text("+", style = MaterialTheme.typography.headlineMedium) }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("زبدتي", style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.ExtraBold, color = Forest)
                    Text("أكلك، حسابك، وبياناتك عندك", color = Muted)
                }
                item {
                    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Forest)) {
                        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("سعرات اليوم", color = Color.White.copy(alpha = .85f))
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text("$calories", color = Color.White, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.width(8.dp))
                                Text("من $goal سعرة", color = Color.White.copy(alpha = .85f))
                            }
                            LinearProgressIndicator(
                                progress = { (calories.toFloat() / goal.coerceAtLeast(1)).coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxWidth().height(8.dp),
                                color = Color(0xFFB8DCC3),
                                trackColor = Color.White.copy(alpha = .2f)
                            )
                            Text(if (calories >= goal) "وصلت لهدفك اليومي" else "باقي ${(goal - calories).coerceAtLeast(0)} سعرة لهدفك",
                                color = Color.White.copy(alpha = .9f))
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MacroCard("بروتين", "${protein}غ", Modifier.weight(1f))
                        MacroCard("كارب", "${carbs}غ", Modifier.weight(1f))
                        MacroCard("دهون", "${fat}غ", Modifier.weight(1f))
                    }
                }
                item {
                    OutlinedButton(
                        onClick = { showPhotoInfo = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp)
                    ) { Text("📷  تحليل وجبة بالصورة (قيد التطوير)") }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("وجبات اليوم", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = {
                            val newGoal = (goal + 200).coerceAtMost(5000)
                            goal = newGoal
                            context.getSharedPreferences("zubdati", Context.MODE_PRIVATE).edit().putInt("goal", goal).apply()
                        }) { Text("رفع الهدف +200") }
                    }
                }
                if (todays.isEmpty()) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("لسه ما سجلت أي وجبة", fontWeight = FontWeight.Bold, color = Ink)
                                Text("اضغط + وسجّل أول وجبة إلك", color = Muted)
                            }
                        }
                    }
                } else {
                    itemsIndexed(todays.reversed()) { _, meal ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(meal.name, fontWeight = FontWeight.Bold, color = Ink)
                                    Text("${meal.protein}غ بروتين · ${meal.carbs}غ كارب · ${meal.fat}غ دهون", color = Muted, style = MaterialTheme.typography.bodySmall)
                                }
                                Text("${meal.calories} سعرة", fontWeight = FontWeight.Bold, color = Forest)
                                Spacer(Modifier.width(8.dp))
                                TextButton(onClick = {
                                    meals.remove(meal)
                                    saveMeals(context, meals)
                                }) { Text("حذف") }
                            }
                        }
                    }
                }
                item {
                    Text("البيانات محفوظة محليًا على هذا الجهاز. خذ نسخة احتياطية قبل حذف التطبيق.", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    if (showAdd) {
        AddMealDialog(
            onDismiss = { showAdd = false },
            onSave = { meal ->
                meals.add(meal)
                saveMeals(context, meals)
                showAdd = false
            }
        )
    }
    if (showPhotoInfo) {
        AlertDialog(
            onDismissRequest = { showPhotoInfo = false },
            title = { Text("تحليل الصور") },
            text = { Text("هاي النسخة الأولى: الواجهة وحفظ الوجبات شغّالان محليًا، لكن تحليل الصور بالذكاء الاصطناعي لسه مش مضاف. رح نضيفه بمرحلة لاحقة بعد اختيار نموذج مجاني مناسب.") },
            confirmButton = { TextButton(onClick = { showPhotoInfo = false }) { Text("تمام") } }
        )
    }
}

@Composable
private fun MacroCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Mint), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 15.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Forest)
            Text(label, color = Muted, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun AddMealDialog(onDismiss: () -> Unit, onSave: (Meal) -> Unit) {
    var name by remember { mutableStateOf("") }
    var calories by remember { mutableStateOf("") }
    var protein by remember { mutableStateOf("0") }
    var carbs by remember { mutableStateOf("0") }
    var fat by remember { mutableStateOf("0") }
    CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("إضافة وجبة") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("اسم الوجبة") }, singleLine = true)
                    OutlinedTextField(calories, { calories = it.filter(Char::isDigit) }, label = { Text("السعرات") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(protein, { protein = it.filter(Char::isDigit) }, label = { Text("بروتين غ") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                        OutlinedTextField(carbs, { carbs = it.filter(Char::isDigit) }, label = { Text("كارب غ") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                        OutlinedTextField(fat, { fat = it.filter(Char::isDigit) }, label = { Text("دهون غ") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isNotBlank() && calories.isNotBlank()) {
                        onSave(Meal(name.trim(), calories.toIntOrNull() ?: 0, protein.toIntOrNull() ?: 0,
                            carbs.toIntOrNull() ?: 0, fat.toIntOrNull() ?: 0, todayKey()))
                    }
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
        )
    }
}
